import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
const firebaseConfig = {
  apiKey: "AIzaSyACYXkmdJ8yqbzxKEMnYyBbHCXJO8RRgms",

  authDomain: "ads-company-285a6.firebaseapp.com",

  projectId: "ads-company-285a6",

  storageBucket: "ads-company-285a6.appspot.com",

  messagingSenderId: "1041458742044",

  appId: "1:1041458742044:web:dcf8702441d52f65feb0d9",

  measurementId: "G-DNBRMNFVLX",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

export const auth = getAuth(app);
