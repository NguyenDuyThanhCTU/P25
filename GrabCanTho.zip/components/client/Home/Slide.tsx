"use client";
import React from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/navigation";
import { Autoplay, Pagination, Navigation } from "swiper/modules";
const Slide = () => {
  const ImageItem = [
    {
      image:
        "https://firebasestorage.googleapis.com/v0/b/grabcantho-1a220.appspot.com/o/z5064414017613_0e71fc37355095c7cae84133c09fe40e.jpg?alt=media&token=abd73d45-aadf-4ad1-b213-b9076e1ca4b2",
    },
    {
      image:
        "https://firebasestorage.googleapis.com/v0/b/grabcantho-1a220.appspot.com/o/z5064414017379_aa8b2cd3f460267aa0d294bb9c2fbecc.jpg?alt=media&token=58e3c2c8-1251-4174-92b4-3b085b846422",
    },
    {
      image:
        "https://firebasestorage.googleapis.com/v0/b/grabcantho-1a220.appspot.com/o/z5064414010438_2c3336eda1c3397175376a16c471360d.jpg?alt=media&token=6f569893-f627-4307-96b1-82b7a35490af",
    },
  ];
  return (
    <div>
      <Swiper
        loop={true}
        spaceBetween={30}
        centeredSlides={true}
        slidesPerView={1}
        slidesPerGroup={1}
        autoplay={{
          delay: 2500,
          disableOnInteraction: false,
        }}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        modules={[Autoplay, Pagination]}
        className="mySwiper"
      >
        <div className="">
          {ImageItem.map((item: any, idx: number) => (
            <div key={idx}>
              {" "}
              <SwiperSlide>
                <div className="h-[50vh] w-full flex justify-center">
                  <img
                    src={item.image}
                    alt="slide"
                    className="h-full object-cover"
                  />
                </div>
              </SwiperSlide>
            </div>
          ))}
        </div>
      </Swiper>
    </div>
  );
};

export default Slide;
