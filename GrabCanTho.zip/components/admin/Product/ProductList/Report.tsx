import React from "react";

const ListProductReport = () => {
  return <div>ListProductReport</div>;
};

export default ListProductReport;
