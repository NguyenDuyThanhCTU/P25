import React from "react";

const ProductSlide = () => {
  return <div>ProductSlide</div>;
};

export default ProductSlide;
