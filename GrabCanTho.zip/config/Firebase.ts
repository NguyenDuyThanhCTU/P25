import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyDZmcRdzyXO29IZ4ZTrAhreKtn2jGhEgjo",

  authDomain: "grabcantho-1a220.firebaseapp.com",

  projectId: "grabcantho-1a220",

  storageBucket: "grabcantho-1a220.appspot.com",

  messagingSenderId: "275174334501",

  appId: "1:275174334501:web:c46d71148445be1773dfcc",

  measurementId: "G-BCK49WKS44",
};

const app = initializeApp(firebaseConfig);
export const db = initializeFirestore(app, {
  experimentalForceLongPolling: true,
});

export const auth = getAuth(app);
